
--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `game`
--
ALTER TABLE `game`
  ADD CONSTRAINT `game_ibfk_1` FOREIGN KEY (`genre_id`) REFERENCES `genre` (`id`);

--
-- Megkötések a táblához `search_history`
--
ALTER TABLE `search_history`
  ADD CONSTRAINT `search_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `search_history_ibfk_2` FOREIGN KEY (`game_id`) REFERENCES `game` (`id`);

--
-- Megkötések a táblához `usergenre`
--
ALTER TABLE `usergenre`
  ADD CONSTRAINT `usergenre_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `usergenre_ibfk_2` FOREIGN KEY (`genre_id`) REFERENCES `genre` (`id`);
