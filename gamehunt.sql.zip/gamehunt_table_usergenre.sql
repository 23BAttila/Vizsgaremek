
-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `usergenre`
--

DROP TABLE IF EXISTS `usergenre`;
CREATE TABLE IF NOT EXISTS `usergenre` (
  `user_id` int(11) NOT NULL,
  `genre_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`genre_id`),
  KEY `genre_id` (`genre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
