
-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `game`
--

DROP TABLE IF EXISTS `game`;
CREATE TABLE IF NOT EXISTS `game` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL,
  `genre_id` int(11) DEFAULT NULL,
  `platform` varchar(100) DEFAULT NULL,
  `release_year` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `genre_id` (`genre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
